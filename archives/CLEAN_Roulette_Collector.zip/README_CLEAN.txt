# 🎰 Сборщик Данных Рулетки - Чистая Версия 
 
Это упрощенная версия проекта только с нужными файлами: 
 
📁 ФАЙЛЫ В ЭТОЙ ПАПКЕ: 
✅ auto_collector_console_code.js - Главный сборщик для браузера 
✅ console_to_analysis.py - Анализатор стратегий 
✅ FOR_FRIEND.txt - НАЧНИТЕ С ЭТОГО ФАЙЛА! 
✅ START_COLLECTOR.txt - Подробные инструкции 
✅ SAVE_STATS_GUIDE.txt - Как сохранять статистику 
✅ roulette_console_data.json - Пример данных 
 
🚀 НАЧАЛО РАБОТЫ: 
1. Прочитайте FOR_FRIEND.txt 
2. Откройте рулетку в браузере 
3. Скопируйте код из auto_collector_console_code.js в консоль 
4. Начинайте сбор данных! 
